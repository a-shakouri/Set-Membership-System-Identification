function [Ad,Bd] = con2dis(Ac,Bc,T)

% MATLAB codes by: Amir Shakouri

Ad=expm(Ac*T);
Bd=Ac\(Ad-eye(length(Ad)))*Bc;

end