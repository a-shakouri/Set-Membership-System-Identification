function [X] = RC_dsim (A,B,W,U,x0,T)


% MATLAB codes by: Amir Shakouri

% Descrete-time simulation of the RC circuit of the letter's Example

X(:,1)=x0;

for t=1:T

    X(:,t+1)=A*X(:,t)+B*U(:,t)+W(:,t);
    
end

end