
% MATLAB codes by: Amir Shakouri

% Main file for the example of RC circuit

clear all;clc

tic

R1=7;
R2=5;
R3=10;
R4=15;
C1=0.5;
C2=0.4;
C3=0.6;

A0=-[0 -1 R3/R4+1;-1 1 R2/R4;1 0 R1/R4];
E=[0 0 R3*C3;0 R2*C2 R2*C3;R1*C1 R1*C2 R1*C3];
B0=-[0 -R3/R4; 0 -R2/R4;-1 -R1/R4];
Ac=E\A0;
Bc=E\B0;

[A,B] = con2dis(Ac,Bc,1);

[n,m]=size(B);

T=10;

epsilon=1e-3;

l=1;

for s=1:1:1000

eta=1/s;

SNRm(l)=eta/epsilon;

for j=1:100

%=============Random Noise=============%

W=random('uniform',-1,1,n,T);

W=epsilon*W/norm(W);

%=========Bound-Exploring Noise=========%

% W=random('uniform',-1,1,n,T);
% 
% [~,~,V] = svd(W);
% 
% W=epsilon*[eye(n) zeros(n,T-n)]*V;

%===========Initial Condition===========%

x0=zeros(n,1);

U=random('uniform',-1,1,m,T);

U=eta*U/min(svd(U));

X=RC_dsim(A,B,W,U,x0,T);

Yp=X(:,2:T+1);
Ym=X(:,1:T);
Um=U(:,1:T);

Phi=blkdiag(epsilon^2*eye(3),-eye(10));

[Phat, Qhat, ~] = sysid_cheb (Yp, Ym, Um, Phi, n, m, 1, 0, 'spectral');


% fprintf('======The common Chebyshev center======');

% Phat

% Qhat

% fprintf('============Chebyshev radii============\n');

% fprintf('Spectral norm:');

[~,~,rad_spec(j,l)] = sysid_cheb (Yp, Ym, Um, Phi, n, m, 1, 0, 'spectral');

% fprintf('Frobenius norm:');

[~,~,rad_Frob(j,l)] = sysid_cheb (Yp, Ym, Um, Phi, n, m, 1, 0, 'Frobenius');

% fprintf('Ky Fan 2-norm:');

[~,~,rad_KF2(j,l)] = sysid_cheb (Yp, Ym, Um, Phi, n, m, 1, 0, 'Ky Fan',2);

% fprintf('Nuclear norm:');

[~,~,rad_nuc(j,l)] = sysid_cheb (Yp, Ym, Um, Phi, n, m, 1, 0, 'nuclear');

end

mean_rad_Frob(l)=mean(rad_Frob(:,l));
var_rad_Frob(l)=var(rad_Frob(:,l));
mean_rad_spec(l)=mean(rad_spec(:,l));
var_rad_spec(l)=var(rad_spec(:,l));
mean_rad_nuc(l)=mean(rad_nuc(:,l));
var_rad_nuc(l)=var(rad_nuc(:,l));

l=l+1;

end

toc

figure(1)

% subplot(1,3,1)
p1=fill([SNRm, flip(SNRm)], [mean_rad_nuc, flip(mean_rad_nuc-var_rad_nuc.^0.5)],[0,0,1],'FaceAlpha',0.1,'LineWidth',0.5);
hold on
p2=fill([SNRm, flip(SNRm)], [mean_rad_nuc, flip(mean_rad_nuc+var_rad_nuc.^0.5)],[0,0,1],'FaceAlpha',0.1,'LineWidth',0.5);
p1.EdgeColor = 'none';
p2.EdgeColor = 'none';

p_nuc=plot(SNRm,mean_rad_nuc,'color',[0,0,1]);
%plot(1./SNRm,mean_rad_nuc-var_rad_nuc.^0.5,'--','color',[0,0,1])
%plot(1./SNRm,mean_rad_nuc+var_rad_nuc.^0.5,'--','color',[0,0,1])

% subplot(1,3,2)
p3=fill([SNRm, flip(SNRm)], [mean_rad_spec, flip(mean_rad_spec-var_rad_spec.^0.5)],[1,0,0],'FaceAlpha',0.1,'LineWidth',0.5);
hold on
p4=fill([SNRm, flip(SNRm)], [mean_rad_spec, flip(mean_rad_spec+var_rad_spec.^0.5)],[1,0,0],'FaceAlpha',0.1,'LineWidth',0.5);
p3.EdgeColor = 'none';
p4.EdgeColor = 'none';

p_spec=plot(SNRm,mean_rad_spec,'color',[1,0,0]);
%plot(1./SNRm,mean_rad_spec-var_rad_spec.^0.5,'--','color',[0,1,0])
%plot(1./SNRm,mean_rad_spec+var_rad_spec.^0.5,'--','color',[0,1,0])

% subplot(1,3,3)
p5=fill([SNRm, flip(SNRm)], [mean_rad_Frob, flip(mean_rad_Frob-var_rad_Frob.^0.5)],[0.3922 0.8314 0.0745],'FaceAlpha',0.1,'LineWidth',0.5);
hold on
p6=fill([SNRm, flip(SNRm)], [mean_rad_Frob, flip(mean_rad_Frob+var_rad_Frob.^0.5)],[0.3922 0.8314 0.0745],'FaceAlpha',0.1,'LineWidth',0.5);
p5.EdgeColor = 'none';
p6.EdgeColor = 'none';

p_Frob=plot(SNRm,mean_rad_Frob,'color',[0.3922 0.8314 0.0745]);
%plot(1./SNRm,mean_rad_spec-var_rad_spec.^0.5,'--','color',[0,1,0])
%plot(1./SNRm,mean_rad_spec+var_rad_spec.^0.5,'--','color',[0,1,0])

legend([p_nuc p_spec p_Frob],{'Nuclear norm','Spectral norm','Frobenius norm'})
set(gca, 'XScale', 'log')
